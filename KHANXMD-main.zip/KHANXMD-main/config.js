// config.js - ESM Version
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (fs.existsSync(path.resolve('config.env'))) {
  dotenv.config({ path: path.resolve('config.env') });
}

// Helper to convert "true"/"false" strings to actual boolean
function convertToBool(text, trueValue = 'true') {
  return text === trueValue;
}

export default {
  // ===== BOT CORE SETTINGS =====
  SESSION_ID: process.env.SESSION_ID || "IK~eyJub2lzZUtleSI6eyJwcml2YXRlIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiR0pVcmJNcmJWQnVHZDlSWE0xVEVhREFsM0wvQ3h1aDgzMDZPZ3EvbmMycz0ifSwicHVibGljIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiZTRYaFIrNE1QQkpacGNRaVBuR2IwMFFNejdxY2RMSFo1U2tlMFFqSVZqTT0ifX0sInBhaXJpbmdFcGhlbWVyYWxLZXlQYWlyIjp7InByaXZhdGUiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiJVR2UyOVlPS0VOdVhxRkppcFpmVlB3WjRNZG5tSThCbytrS1RUUDFLL2x3PSJ9LCJwdWJsaWMiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiIxNUlSY1J2c2UwbUJmWkNVNitqa0pVeXUzMmFXT3NPUlJHaTJ2RHBnMVZjPSJ9fSwic2lnbmVkSWRlbnRpdHlLZXkiOnsicHJpdmF0ZSI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6IjBGTC91bGk2SnR3NGpKa3dFSlVWaytrQWRIM1BZd0oxbEZMMC8rR2E4RU09In0sInB1YmxpYyI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6IlBnWFMxMmNLT1RhZ01UQTgrZXNuSmg3Y3JyaHZCcElHc1d5NzRBRWkvbDA9In19LCJzaWduZWRQcmVLZXkiOnsia2V5UGFpciI6eyJwcml2YXRlIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiZ0RiQzBLZ1ZiTnVFVkJTV01rRFlXNmp4akxBcnQvVjdKWk5oT0ZBL0ZsYz0ifSwicHVibGljIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoidjZYOW5iaERFQzkyQXJyUGlXR0xlWEtRS1hwM0lydVBSRnZPWktieVZ5cz0ifX0sInNpZ25hdHVyZSI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6ImpzUC9nVktDc29UdDRnNkRjSVV0RE0yMnRkV1FKS0ZqNE1LNEp6SlFiaVNjTkthbDQxNEpENEJYTWd2RTRidkRwK2t6RTExdXlaWTJlb3d6WkFreUJBPT0ifSwia2V5SWQiOjF9LCJyZWdpc3RyYXRpb25JZCI6MTc3LCJhZHZTZWNyZXRLZXkiOiJScWxMMnU1eG5hTDFaZDlMbzJRVHlSQnBPeGkvcTQyaWw0azV5ZW1LMzB3PSIsInByb2Nlc3NlZEhpc3RvcnlNZXNzYWdlcyI6W3sia2V5Ijp7InJlbW90ZUppZCI6IjkyMzAzMDA0MzY3OEBzLndoYXRzYXBwLm5ldCIsImZyb21NZSI6dHJ1ZSwiaWQiOiJBNTMyNTg0OEFCQjZBQ0JCNDM3REVGRTc1RjNEMUNCOSIsInBhcnRpY2lwYW50IjoiIiwiYWRkcmVzc2luZ01vZGUiOiJwbiJ9LCJtZXNzYWdlVGltZXN0YW1wIjoxNzg4OTU0MjI3fV0sIm5leHRQcmVLZXlJZCI6ODEzLCJmaXJzdFVudXBsb2FkZWRQcmVLZXlJZCI6ODEzLCJhY2NvdW50U3luY0NvdW50ZXIiOjAsImFjY291bnRTZXR0aW5ncyI6eyJ1bmFyY2hpdmVDaGF0cyI6ZmFsc2V9LCJyZWdpc3RlcmVkIjp0cnVlLCJwYWlyaW5nQ29kZSI6Ilk5UTNWQjFYIiwibWUiOnsiaWQiOiI5MjMwMzAwNDM2Nzg6MTdAcy53aGF0c2FwcC5uZXQiLCJuYW1lIjoiU3llZCBHbSBTaGFoIiwibGlkIjoiNDYxNzEzMDExMzAyOTE6MTdAbGlkIn0sImFjY291bnQiOnsiZGV0YWlscyI6IkNPVzk4cFFIRU9HTWhkVUdHQU1nQUNnQSIsImFjY291bnRTaWduYXR1cmVLZXkiOiJQYmlWbHpBU1R0dWhrTXU2Q3IxZzlFZ1hEQUhLRHZZN0pKRklDRHNWK0YwPSIsImFjY291bnRTaWduYXR1cmUiOiJCQmFuc3VMTGxxTmZ3MFI4MlYvc3lBWG81VzF4amZ4R0RCclpDckl4OG9ZZlkvOTJ5Ukd2Z2laOVVLVjZ2dkp1QXlZY3dBNStCZlVURlh6MUlWZ1NBZz09IiwiZGV2aWNlU2lnbmF0dXJlIjoiQUdpT0RzSzlKTkYwU2lZS2crenBNL2l6NHBOV3NpeEl6WDMyMWl3TGtZT3Y0RVpTbGhFMVp4blJOOWQ3aUpXQURTZERjOUlmRmJnUDFKalUxZmE5QlE9PSJ9LCJzaWduYWxJZGVudGl0aWVzIjpbeyJpZGVudGlmaWVyIjp7Im5hbWUiOiI0NjE3MTMwMTEzMDI5MToxN0BsaWQiLCJkZXZpY2VJZCI6MH0sImlkZW50aWZpZXJLZXkiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiJCVDI0bFpjd0VrN2JvWkRMdWdxOVlQUklGd3dCeWc3Mk95U1JTQWc3RmZoZCJ9fV0sInBsYXRmb3JtIjoic21iYSIsInJvdXRpbmdJbmZvIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiQ0FJSURRZ1MifSwibGFzdEFjY291bnRTeW5jVGltZXN0YW1wIjoxNzg4OTU0MjI1LCJsYXN0UHJvcEhhc2giOiIxUzlzaksiLCJteUFwcFN0YXRlS2V5SWQiOiJBQUFBQUUzWSJ9",
  PREFIX: process.env.PREFIX || ".",
  CHATBOT: process.env.CHATBOT || "off",
  BOT_NAME: process.env.BOT_NAME || "MURSHAD",
  MODE: process.env.MODE || "private",
  REPO: process.env.REPO || "https://github.com/JawadTechYT/KHAN-MD",
  WEBPAIR: process.env.WEBPAIR || "https://khanmd-pairx.onrender.com",
  NEWSLETTERID: process.env.NEWSLETTERID || "120363426563532140@newsletter",
 
  // ===== OWNER & DEVELOPER SETTINGS =====
  OWNER_NUMBER: process.env.OWNER_NUMBER || "923030043678",
  OWNER_NAME: process.env.OWNER_NAME || "GM SHAH",
  SUDO: process.env.SUDO 
    ? process.env.SUDO.split(',').map(s => s.trim()) 
    : ["123@lid"],
  BANNED: process.env.BANNED 
    ? process.env.BANNED.split(',').map(s => s.trim()) 
    : [],
  STATUS_LIKE_EMOJIS: process.env.STATUS_LIKE_EMOJIS 
    ? process.env.STATUS_LIKE_EMOJIS.split(',').map(e => e.trim()) 
    : ["❤️", "🔥", "👍", "😍", "💯"],
  REACT_EMOJIS: process.env.REACT_EMOJIS 
    ? process.env.REACT_EMOJIS.split(',').map(e => e.trim()) 
    : ["❤️", "🔥", "👍", "😍", "❤️‍🩹", "💗", "💖", "🧡", "💚", "💜", "💯", "🤍", "🩶", "💜", "🩵", "♥️", "💛", "♥️", "🤎", "💘", "💝", "💖", "💗", "💟", "❣️", "💔", "🤙", "💖", "💕", "💗", "👑", "💎", "🌟", "🎯", "🎨", "❤️‍🔥", "💞", "💌", "💕", "💘"],
  OWNER_EMOJIS: process.env.OWNER_EMOJIS 
    ? process.env.OWNER_EMOJIS.split(',').map(e => e.trim()) 
    : ["❤️", "💓", "♥️", "❣️", "💌", "❤️‍🔥", "❤️‍🩹", "💓", "❣️", "💕", "💘", "💝", "💜", "🤍", "🩵", "💜", "💛", "💔", "🩷", "🤍"],
  LINK_WARNINGS: process.env.LINK_WARNINGS 
    ? process.env.LINK_WARNINGS.split(',').map(s => s.trim()).filter(s => s) 
    : [],
 
  // ===== HEROKU SETTINGS =====
  HEROKU_API_KEY: process.env.HEROKU_API_KEY || "",
  HEROKU_APP_NAME: process.env.HEROKU_APP_NAME || "",

  // ===== AUTO-RESPONSE SETTINGS =====
  AUTO_REPLY: process.env.AUTO_REPLY || "false",
  AUTO_STATUS_REPLY: process.env.AUTO_STATUS_REPLY || "false",
  AUTO_STATUS_MSG: process.env.AUTO_STATUS_MSG || "*GM VIEWED YOUR STATUS 🤖*",
  READ_MESSAGE: process.env.READ_MESSAGE || "false",
  REJECT_MSG: process.env.REJECT_MSG || "*📞 ᴄαℓℓ ɴσт αℓℓσωє∂ ιɴ тнιѕ ɴᴜмвєʀ уσυ ∂σɴт нανє ᴘєʀмιѕѕισɴ 📵*",

  // ===== REACTION SETTINGS =====
  AUTO_REACT: process.env.AUTO_REACT || "true",
  OWNER_REACT: process.env.OWNER_REACT || "false",
  STICKER_NAME: process.env.STICKER_NAME || "⁰³⁰³⚡SYED⚡ ⁰⁰⁴³GM ⁶⁷⁸⚡SHAH⚡ 💖",
  AUTO_STICKER: process.env.AUTO_STICKER || "false",
  AUTO_VOICE: process.env.AUTO_VOICE || "false",
  STATUS_SENDER: process.env.STATUS_SENDER || "true",
  
  // ===== AUTO PRESENCE SETTINGS =====
  ALWAYS_ONLINE: process.env.ALWAYS_ONLINE || "false",
  AUTO_TYPING: process.env.AUTO_TYPING || "false",
  AUTO_RECORDING: process.env.AUTO_RECORDING || "false",

  // ===== ANTI FEATURES SETTINGS =====
  ANTI_LINK: process.env.ANTI_LINK || "true",
  ANTI_STATUS: process.env.ANTI_STATUS || "true",
  ANTI_BAD_WORD: process.env.ANTI_BAD_WORD || "false",

  // ===== MEDIA & AUTOMATION =====
  MENTION_REPLY: process.env.MENTION_REPLY || "false",
  MENU_IMAGE_URL: process.env.MENU_IMAGE_URL || "https://files.catbox.moe/6zd0ru.jpg",
  BOT_MEDIA_URL: process.env.BOT_MEDIA_URL || "https://files.catbox.moe/6zd0ru.jpg",
  AUDIO_URL: process.env.AUDIO_URL || 'https://files.catbox.moe/0toicz.mp3',
  AUTO_DOWNLOADER: process.env.AUTO_DOWNLOADER || "false",
  
  // ===== SECURITY & ANTI-FEATURES =====
  ANTI_DELETE: process.env.ANTI_DELETE || "true",
  ANTI_DELETE_PATH: process.env.ANTI_DELETE_PATH || "inbox",
  ANTI_CALL: process.env.ANTI_CALL || "false",
  ANTI_SPAM: process.env.ANTI_SPAM || "false",
  ANTI_VV: process.env.ANTI_VV || "true",
  ANTI_BOT: process.env.ANTI_BOT || "false",
  PM_BLOCKER: process.env.PM_BLOCKER || "false",
  ANTI_MENTION: process.env.ANTI_MENTION || "false",
  ANTI_STATUS_MENTION: process.env.ANTI_STATUS_MENTION || "false",
  ANTI_EDIT: process.env.ANTI_EDIT || "true",
  ANTIEDIT_PATH: process.env.ANTIEDIT_PATH || "inbox",

  // ===== BOT BEHAVIOR & APPEARANCE =====
  DESCRIPTION: process.env.DESCRIPTION || "*© ᴘᴏᴡᴇʀᴇᴅ ʙʏ ⁰³⁰³⚡SYED⚡ ⁰⁰⁴³GM ⁶⁷⁸⚡SHAH⚡ 💖*",
  AUTO_VIEW_STATUS: process.env.AUTO_VIEW_STATUS || "true",
  AUTO_LIKE_STATUS: process.env.AUTO_LIKE_STATUS || "false",
  AUTO_BIO: process.env.AUTO_BIO || "false",
  AUTO_LIKE_EMOJI: process.env.AUTO_LIKE_EMOJI 
    ? process.env.AUTO_LIKE_EMOJI.split(',').map(e => e.trim()) 
    : ["❤️", "🔥", "👍", "😍", "💀"],
  
  // ===== WELCOME & GOODBYE SETTINGS =====
  WELCOME: process.env.WELCOME || "false",
  GOODBYE: process.env.GOODBYE || "false",
  ADMIN_ACTION: process.env.ADMIN_ACTION || "false",
  WELCOME_MESSAGE: process.env.WELCOME_MESSAGE || "*_@user joined the group, welcome! 🎉_*",
  GOODBYE_MESSAGE: process.env.GOODBYE_MESSAGE || "*_@user has left the group, we will miss them! 👋_*",

  VERSION: process.env.VERSION || "10.0 Bᴇᴛᴀ",
  TIMEZONE: process.env.TIMEZONE || "Asia/Karachi",
};
