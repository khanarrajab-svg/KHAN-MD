// config.js - ESM Version
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (fs.existsSync(path.resolve('config.env'))) {
  dotenv.config({ path: path.resolve('config.env') });
}

// Helper to convert "true"/"false" strings to actual boolean
function convertToBool(text, trueValue = 'true') {
  return text === trueValue;
}

export default {
  // ===== BOT CORE SETTINGS =====
  SESSION_ID: process.env.SESSION_ID || "IK~eyJub2lzZUtleSI6eyJwcml2YXRlIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiVUlLTXljQ0tWVENEZ2x5MDBpMmJTR3dYbkkvU1U5N1FKS20xa3hkZFZuUT0ifSwicHVibGljIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiNFlSUkJxcVhXSS81bW50dW9qL1dmVGdtVmtXM3NrR20rdStnazNyQXFYYz0ifX0sInBhaXJpbmdFcGhlbWVyYWxLZXlQYWlyIjp7InByaXZhdGUiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiJPSHpGZXNwR1E3WXduaXRVSlVQRFZjU3h1T2xBa2VkM2JVM2pwNzM0YkdjPSJ9LCJwdWJsaWMiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiIzSWRrR1lwYUpTUExFQ0xIVi9oVjR3ZW1uMVowZVJMRCtYRitSeUhQMmtJPSJ9fSwic2lnbmVkSWRlbnRpdHlLZXkiOnsicHJpdmF0ZSI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6IndKYXFUdEMrZHplcG5VaUMwd0lpemwvTGo3TmtIQ1hhVmJGcWVaTlpGR3c9In0sInB1YmxpYyI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6InJzN083UzJiVlkrVmJLMjU1UEJHak1RdklsYTZ1M3c1QXNKd3RFTXhvaGs9In19LCJzaWduZWRQcmVLZXkiOnsia2V5UGFpciI6eyJwcml2YXRlIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiZVBaOVE1ZEc2RXhoamxRNjZtdFBNUzl6UWIvMlZaV2ZKeVA1NXpXcjczTT0ifSwicHVibGljIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoibjE3V3QvL3JqTVgvbU5BWTdzVXkwSUFvR0dOWmVvSjd2T21yMVAzVWFGdz0ifX0sInNpZ25hdHVyZSI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6IlNjVFNhZnl0TWhZWlRYRFQwV0NXeFdxbmFTc3AwRU1lV2dQaGIyUTlVZVdXblM1YWcveFExTmlnMnhqTGlYU3ZqRzVJQzVLRk45aUlxQWIxaWMwSGdnPT0ifSwia2V5SWQiOjF9LCJyZWdpc3RyYXRpb25JZCI6NTcsImFkdlNlY3JldEtleSI6IkMwRmN5bENpVFhNQzczMmRyRXpoLzBLU0Qrd3laWDdjVjRHYkFJbnlRU2M9IiwicHJvY2Vzc2VkSGlzdG9yeU1lc3NhZ2VzIjpbeyJrZXkiOnsicmVtb3RlSmlkIjoiOTIzMTg3MDkyNDk1QHMud2hhdHNhcHAubmV0IiwiZnJvbU1lIjp0cnVlLCJpZCI6IkFDQTdCMjQ4MTgyQTY5RDMxNUVGRDY3QzQ1NDYxQjZGIiwicGFydGljaXBhbnQiOiIiLCJhZGRyZXNzaW5nTW9kZSI6InBuIn0sIm1lc3NhZ2VUaW1lc3RhbXAiOjE3ODkwNTEzODl9LHsia2V5Ijp7InJlbW90ZUppZCI6IjkyMzE4NzA5MjQ5NUBzLndoYXRzYXBwLm5ldCIsImZyb21NZSI6dHJ1ZSwiaWQiOiJBQ0Y5NzA4Qjg2OTMzN0I2QzU2NDIzQURCOEM4OTQ0NCIsInBhcnRpY2lwYW50IjoiIiwiYWRkcmVzc2luZ01vZGUiOiJwbiJ9LCJtZXNzYWdlVGltZXN0YW1wIjoxNzg5MDUxMzkyfSx7ImtleSI6eyJyZW1vdGVKaWQiOiI5MjMxODcwOTI0OTVAcy53aGF0c2FwcC5uZXQiLCJmcm9tTWUiOnRydWUsImlkIjoiQUNDQjNEQzhFQjZCNEZCQ0RGMDQxMDkzQkNFQTAyM0MiLCJwYXJ0aWNpcGFudCI6IiIsImFkZHJlc3NpbmdNb2RlIjoicG4ifSwibWVzc2FnZVRpbWVzdGFtcCI6MTc4OTA1MTM5Mn0seyJrZXkiOnsicmVtb3RlSmlkIjoiOTIzMTg3MDkyNDk1QHMud2hhdHNhcHAubmV0IiwiZnJvbU1lIjp0cnVlLCJpZCI6IkFDRTRDQTExNDIzNTdEMzI5RkE3NzBENEUyNTRCMERCIiwicGFydGljaXBhbnQiOiIiLCJhZGRyZXNzaW5nTW9kZSI6InBuIn0sIm1lc3NhZ2VUaW1lc3RhbXAiOjE3ODkwNTEzOTZ9XSwibmV4dFByZUtleUlkIjo4MTMsImZpcnN0VW51cGxvYWRlZFByZUtleUlkIjo4MTMsImFjY291bnRTeW5jQ291bnRlciI6MSwiYWNjb3VudFNldHRpbmdzIjp7InVuYXJjaGl2ZUNoYXRzIjpmYWxzZX0sInJlZ2lzdGVyZWQiOnRydWUsInBhaXJpbmdDb2RlIjoiWFNERDNOUVAiLCJtZSI6eyJpZCI6IjkyMzE4NzA5MjQ5NToxMEBzLndoYXRzYXBwLm5ldCIsImxpZCI6IjE5MzY1MjAyMjMxMzA2MzoxMEBsaWQifSwiYWNjb3VudCI6eyJkZXRhaWxzIjoiQ09LWTcrSUJFT3lEaTlVR0dBRWdBQ2dBIiwiYWNjb3VudFNpZ25hdHVyZUtleSI6IjF5UG1OWmpTUmVyQTdwRUM5WitsRUJrenEyZHRrOE01TE4vMUFEUjlZSHM9IiwiYWNjb3VudFNpZ25hdHVyZSI6Inh6S3M2SDNhVmFzZzJqL0Z1VGRTWFdGN0twUGZidnlQQ3JkRk9KejJhSlBxWUcyWnZkc0VGaXJaQWl4QXBWOUR0Y1lFRTIzNTBBUUovc1dCcHNzTURBPT0iLCJkZXZpY2VTaWduYXR1cmUiOiJ3T0Q5VS9yTHdmSjJ1SU1GdTFmbXpLbVNiWU94anBETHZSRkY2ZytWVFJGamVVY0hweitMTGQyN1Z6NzEvNGFGQWw4Y0lidjVlMS95VXpWdmlqOVdnUT09In0sInNpZ25hbElkZW50aXRpZXMiOlt7ImlkZW50aWZpZXIiOnsibmFtZSI6IjE5MzY1MjAyMjMxMzA2MzoxMEBsaWQiLCJkZXZpY2VJZCI6MH0sImlkZW50aWZpZXJLZXkiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiJCZGNqNWpXWTBrWHF3TzZSQXZXZnBSQVpNNnRuYlpQRE9TemY5UUEwZldCNyJ9fV0sInBsYXRmb3JtIjoiYW5kcm9pZCIsInJvdXRpbmdJbmZvIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiQ0FJSUJRZ0kifSwibGFzdEFjY291bnRTeW5jVGltZXN0YW1wIjoxNzg5MDUxMzg3LCJteUFwcFN0YXRlS2V5SWQiOiJBQUFBQU1jSCIsImxhc3RQcm9wSGFzaCI6IjJzZUozaSJ9",
  PREFIX: process.env.PREFIX || ".",
  CHATBOT: process.env.CHATBOT || "off",
  BOT_NAME: process.env.BOT_NAME || "MURSHAD",
  MODE: process.env.MODE || "private",
  REPO: process.env.REPO || "https://github.com/JawadTechYT/KHAN-MD",
  WEBPAIR: process.env.WEBPAIR || "https://khanmd-pairx.onrender.com",
  NEWSLETTERID: process.env.NEWSLETTERID || "120363426563532140@newsletter",
 
  // ===== OWNER & DEVELOPER SETTINGS =====
  OWNER_NUMBER: process.env.OWNER_NUMBER || "923030043678",
  OWNER_NAME: process.env.OWNER_NAME || "GM SHAH",
  SUDO: process.env.SUDO 
    ? process.env.SUDO.split(',').map(s => s.trim()) 
    : ["123@lid"],
  BANNED: process.env.BANNED 
    ? process.env.BANNED.split(',').map(s => s.trim()) 
    : [],
  STATUS_LIKE_EMOJIS: process.env.STATUS_LIKE_EMOJIS 
    ? process.env.STATUS_LIKE_EMOJIS.split(',').map(e => e.trim()) 
    : ["❤️", "🔥", "👍", "😍", "💯"],
  REACT_EMOJIS: process.env.REACT_EMOJIS 
    ? process.env.REACT_EMOJIS.split(',').map(e => e.trim()) 
    : ["❤️", "🔥", "👍", "😍", "❤️‍🩹", "💗", "💖", "🧡", "💚", "💜", "💯", "🤍", "🩶", "💜", "🩵", "♥️", "💛", "♥️", "🤎", "💘", "💝", "💖", "💗", "💟", "❣️", "💔", "🤙", "💖", "💕", "💗", "👑", "💎", "🌟", "🎯", "🎨", "❤️‍🔥", "💞", "💌", "💕", "💘"],
  OWNER_EMOJIS: process.env.OWNER_EMOJIS 
    ? process.env.OWNER_EMOJIS.split(',').map(e => e.trim()) 
    : ["❤️", "💓", "♥️", "❣️", "💌", "❤️‍🔥", "❤️‍🩹", "💓", "❣️", "💕", "💘", "💝", "💜", "🤍", "🩵", "💜", "💛", "💔", "🩷", "🤍"],
  LINK_WARNINGS: process.env.LINK_WARNINGS 
    ? process.env.LINK_WARNINGS.split(',').map(s => s.trim()).filter(s => s) 
    : [],
 
  // ===== HEROKU SETTINGS =====
  HEROKU_API_KEY: process.env.HEROKU_API_KEY || "",
  HEROKU_APP_NAME: process.env.HEROKU_APP_NAME || "",

  // ===== AUTO-RESPONSE SETTINGS =====
  AUTO_REPLY: process.env.AUTO_REPLY || "false",
  AUTO_STATUS_REPLY: process.env.AUTO_STATUS_REPLY || "false",
  AUTO_STATUS_MSG: process.env.AUTO_STATUS_MSG || "*GM VIEWED YOUR STATUS 🤖*",
  READ_MESSAGE: process.env.READ_MESSAGE || "false",
  REJECT_MSG: process.env.REJECT_MSG || "*📞 ᴄαℓℓ ɴσт αℓℓσωє∂ ιɴ тнιѕ ɴᴜмвєʀ уσυ ∂σɴт нανє ᴘєʀмιѕѕισɴ 📵*",

  // ===== REACTION SETTINGS =====
  AUTO_REACT: process.env.AUTO_REACT || "true",
  OWNER_REACT: process.env.OWNER_REACT || "false",
  STICKER_NAME: process.env.STICKER_NAME || "⁰³⁰³⚡SYED⚡ ⁰⁰⁴³GM ⁶⁷⁸⚡SHAH⚡ 💖",
  AUTO_STICKER: process.env.AUTO_STICKER || "false",
  AUTO_VOICE: process.env.AUTO_VOICE || "false",
  STATUS_SENDER: process.env.STATUS_SENDER || "true",
  
  // ===== AUTO PRESENCE SETTINGS =====
  ALWAYS_ONLINE: process.env.ALWAYS_ONLINE || "false",
  AUTO_TYPING: process.env.AUTO_TYPING || "false",
  AUTO_RECORDING: process.env.AUTO_RECORDING || "false",

  // ===== ANTI FEATURES SETTINGS =====
  ANTI_LINK: process.env.ANTI_LINK || "true",
  ANTI_STATUS: process.env.ANTI_STATUS || "true",
  ANTI_BAD_WORD: process.env.ANTI_BAD_WORD || "false",

  // ===== MEDIA & AUTOMATION =====
  MENTION_REPLY: process.env.MENTION_REPLY || "false",
  MENU_IMAGE_URL: process.env.MENU_IMAGE_URL || "https://files.catbox.moe/6zd0ru.jpg",
  BOT_MEDIA_URL: process.env.BOT_MEDIA_URL || "https://files.catbox.moe/6zd0ru.jpg",
  AUDIO_URL: process.env.AUDIO_URL || 'https://files.catbox.moe/0toicz.mp3',
  AUTO_DOWNLOADER: process.env.AUTO_DOWNLOADER || "false",
  
  // ===== SECURITY & ANTI-FEATURES =====
  ANTI_DELETE: process.env.ANTI_DELETE || "true",
  ANTI_DELETE_PATH: process.env.ANTI_DELETE_PATH || "inbox",
  ANTI_CALL: process.env.ANTI_CALL || "false",
  ANTI_SPAM: process.env.ANTI_SPAM || "false",
  ANTI_VV: process.env.ANTI_VV || "true",
  ANTI_BOT: process.env.ANTI_BOT || "false",
  PM_BLOCKER: process.env.PM_BLOCKER || "false",
  ANTI_MENTION: process.env.ANTI_MENTION || "false",
  ANTI_STATUS_MENTION: process.env.ANTI_STATUS_MENTION || "false",
  ANTI_EDIT: process.env.ANTI_EDIT || "true",
  ANTIEDIT_PATH: process.env.ANTIEDIT_PATH || "inbox",

  // ===== BOT BEHAVIOR & APPEARANCE =====
  DESCRIPTION: process.env.DESCRIPTION || "*© ᴘᴏᴡᴇʀᴇᴅ ʙʏ ⁰³⁰³⚡SYED⚡ ⁰⁰⁴³GM ⁶⁷⁸⚡SHAH⚡ 💖*",
  AUTO_VIEW_STATUS: process.env.AUTO_VIEW_STATUS || "true",
  AUTO_LIKE_STATUS: process.env.AUTO_LIKE_STATUS || "false",
  AUTO_BIO: process.env.AUTO_BIO || "false",
  AUTO_LIKE_EMOJI: process.env.AUTO_LIKE_EMOJI 
    ? process.env.AUTO_LIKE_EMOJI.split(',').map(e => e.trim()) 
    : ["❤️", "🔥", "👍", "😍", "💀"],
  
  // ===== WELCOME & GOODBYE SETTINGS =====
  WELCOME: process.env.WELCOME || "false",
  GOODBYE: process.env.GOODBYE || "false",
  ADMIN_ACTION: process.env.ADMIN_ACTION || "false",
  WELCOME_MESSAGE: process.env.WELCOME_MESSAGE || "*_@user joined the group, welcome! 🎉_*",
  GOODBYE_MESSAGE: process.env.GOODBYE_MESSAGE || "*_@user has left the group, we will miss them! 👋_*",

  VERSION: process.env.VERSION || "10.0 Bᴇᴛᴀ",
  TIMEZONE: process.env.TIMEZONE || "Asia/Karachi",
};
